/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

/**
 *
 * @author likhita
 */
public class Lab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Student bob = new Student();
        System.out.println(bob.firstName);
        System.out.println(bob.studentId);
        System.out.println(bob.gender);
        System.out.println(bob.age);
        System.out.println(bob.liveOnCampus);
         */
 /*
        Student john = new Student("John", "800123456", 'm', 20, true);
        System.out.println(john.firstName);
        System.out.println(john.studentId);
        System.out.println(john.gender);
        System.out.println(john.age);
        System.out.println(john.liveOnCampus);
         */
        Student mary = new Student("Joan", "80023457", 'f', 19, false);
        System.out.println("Object mary first name is " + mary.getFirstName());
        mary.setFirstName("Sue");
        System.out.println("Object mary first name is " + mary.getFirstName());
        
        System.out.println(" ");
        mary.transferToCard(650);
        mary.transferToCard(-250);
        mary.payFromCard(120);
        mary.payFromCard(500);

    }

}
