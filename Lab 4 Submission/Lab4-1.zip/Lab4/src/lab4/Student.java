/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

/**
 * Student class to specify the behavior of Student in an University
 * @author likhita
 * @version 1.0
 */
public class Student {

    private String firstName;
    private String studentId;
    private char gender;
    private int age;
    private boolean liveOnCampus;
    private double balance;

    /**
     *
     * @param fName is the first name of the student 
     * @param ID is the student id 
     * @param studentGender is the student's gender
     * @param studentAge is the student's age 
     * @param isLiveOnCampus is if the student lives on campus or not
     */
    public Student(String fName, String ID, char studentGender, int studentAge, boolean isLiveOnCampus) {
        firstName = fName;
        studentId = ID;
        gender = studentGender;
        age = studentAge;
        liveOnCampus = isLiveOnCampus;
        balance = 0;
    }

    /**
     *
     * @return statement to get the student's first name 
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     *
     * @return statement to get the student's student id number
     */
    public String getStudentId() {
        return studentId;
    }

    /**
     *
     * @return statement to get the gender of the student  
     */
    public char getGender() {
        return gender;
    }

    /**
     *
     * @return statement to get the age of the student 
     */
    public int getAge() {
        return age;
    }

    /**
     *
     * @return statement to determine if the student lives on campus or not
     */
    public boolean getliveOnCampus() {
        return liveOnCampus;
    }

    /**
     *
     * @param fName constructor that creates and initializes the objects with the values passed to get the student's first name 
     */
    public void setFirstName(String fName) {
        firstName = fName;
    }

    /**
     *
     * @param studentAge constructor that creates and initializes the objects with the values passed to get the student's age 
     */
    public void setAge(int studentAge) {
        age = studentAge;
    }

    /**
     *
     * @param ID constructor that creates and initializes the objects with the values passed to get the student's ID
     */
    public void setStudentId(String ID) {
        studentId = ID;
    }

    /**
     *
     * @param studentGender constructor that creates and initializes the objects with the values passed to get the student's gender
     */
    public void setGender(char studentGender) {
        gender = studentGender;
    }

    /**
     *
     * @param isLiveOnCampus constructor that creates and initializes the objects with the values passed to get the student's living situation
     */
    public void setLiveOnCampus(boolean isLiveOnCampus) {
        liveOnCampus = isLiveOnCampus;
    }

    /**
     *
     * @return statement to get the student's balance 
     */
    public double getBalance() {
        return balance;
    }

    /**
     *
     * @param amount transferToCard to call the amount of money being transferred from the object created 
     */
    public void transferToCard(double amount) {

        if (amount > 0) {
            balance += amount;
            System.out.println("Balance : " + balance);
        } else {
            System.out.println("The transfer amount must be greater than 0");
        }
    }

    /**
     *
     * @param amount payFromCard to call the amount of money being transferred from the object created
     */
    public void payFromCard(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Balance : " + balance);
        } else {
            System.out.println("Sorry, your balance is too low!");
        }
    }
}
